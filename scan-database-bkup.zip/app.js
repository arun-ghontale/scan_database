const express = require('express')
const path = require('path');
const app = express()
const port = process.env.PORT||3000
const mongoose = require('mongoose')
const socketIO = require('socket.io');
const http = require('http');
let Users = new Object();
const cookieParser = require('cookie-parser')
const session = require('express-session');
const publicPath = path.join(__dirname,'./public');
const CookieIdentifier = 'AAET'

app.use(cookieParser());


/////////////////////////////to maintain sessions///////////////////////////
// const MongoStore = require('connect-mongo')(session);
// app.use(session({
//     secret: CookieIdentifier, 
//     store: new MongoStore({
//         url: 'mongodb://localhost/scan-database',
//         ttl: 14 * 24 * 60 * 60 // = 14 days. Default
//       })
//     })
// );
//req.session.destroy();
/////////////////////////////to maintain sessions///////////////////////////

// set a cookie
app.use(function (req, res, next) {
  // check if client sent cookie
  var cookie = req.cookies.cookieName;
  if ((cookie === undefined) || !(cookie.startsWith(CookieIdentifier)))
  {
    // no: set a new cookie
    let randomNumber=CookieIdentifier+Math.random().toString();
    while('CookieName='+randomNumber in Users){
        randomNumber=CookieIdentifier+Math.random().toString();
    }
    res.cookie('cookieName',randomNumber, { maxAge: 900000000 });
    console.log('cookie created successfully',req.sessionID);
} 
  else
  {
    // yes, cookie was already present 
    console.log('cookie exists', cookie,req.sessionID);
  } 
  next(); // <-- important!
});


//allow cross origin sharing
const cors = require('cors');
app.use(cors());
app.options('*', cors());



const bodyParser = require('body-parser')
//Do not include the rich text formats by setting it to false
app.use(bodyParser.urlencoded({extended: false}))
app.use(bodyParser.json())

const mongoDB = 'mongodb://localhost:27017/scan-database';
mongoose.connect(mongoDB,{useNewUrlParser: true});
const scanRoutes = require('./routes/scan')

var server = http.createServer(app);
//socket IO with server
var io = socketIO(server);
//listen to a specific event


// socket event is connection here
io.on('connection', (socket)=>{
    //when a user connects update the Users object and send the status of the number of connections
    socket.on('setCookie',(data)=>{
        var cookieDataConnect = data.cookie.split(";")
        var cookieConnect = cookieDataConnect[cookieDataConnect.length-1].trim()
        if (!(cookieConnect in Users)){
            Users[cookieConnect] = 1;
        }
        else{
            Users[cookieConnect] += 1;
        }

        userLength = Object.keys(Users).filter((each)=>{
            if(!(Users[each] == 0)){
                return true
            }
            else{
                return false

            }
        }).length
        console.log('A User connected',cookieConnect,userLength)
        io.emit('userConnection',{users:userLength})    
    })
    
    //when a user disconnects update the Users object and send the status of the number of connections
    socket.on('leave', (data)=>{
        var cookieDataDisconnect = data.cookie.split(";")
        var cookieDisconnect = cookieDataDisconnect[cookieDataDisconnect.length-1].trim()
        
        Users[cookieDisconnect] -= 1;

        userLength = Object.keys(Users).filter((each)=>{
            if(!(Users[each] == 0)){
                return true
            }
            return false
        }).length
        
        console.log('A User disconnected',cookieDisconnect,userLength)
        io.emit('userConnection',{users:userLength})
    })
})


app.set('socketio',io);
app.use(express.static(publicPath));
app.use('/scan',scanRoutes);
server.listen(port, () => console.log(`Example app listening on port ${port}!`))