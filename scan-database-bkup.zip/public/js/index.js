var socket = io();

// socket event is connect here -> inbuilt event
socket.on('connect',()=>{
    // $.getJSON('https://httpbin.org/ip', function(data) {
    //             console.log(typeof data['origin'],data);
    // });
    
    // $.getJSON("https://api.ipify.org/?format=json", function(e) {
    // console.log(e);
    // });
    socket.emit('setCookie',{cookie:document.cookie})
    console.log('connected to server');
})



socket.on('userConnection',(users)=>{
    console.log(users.users)
    $(document).ready(function(){
        $('#chatroom')[0].innerHTML = `users:${users.users}`;
        });
    });

$(window).on("beforeunload", function() { 
    socket.emit('leave',{cookie:document.cookie})
})



socket.on('updateDoc',(updateValue) => {
    /*
        {
            'id':the doc id,
            'done_status':0 or 1,
            'error':0 or 1
        }
    */
    console.log(updateValue)
    if (updateValue.error === 1){
        console.log('error')
    }
    else{
        console.log('No error')
    }
    /*
     If a done/undone is clicked, then update that particular ids done/undone
    */
    // let li = jQuery('<li></li>');
    // li.text(`${newMessage.from}: ${newMessage.text}`)
    // jQuery('#messages').append(li);
})

jQuery('#date-select').on('submit',function(e){
    e.preventDefault();
    let date = jQuery('[name=evalDate]').val()
    $.post("http://localhost:3000/scan/submissions",
    {
       "start_year":2018,
       "start_month":11,
       "start_day":25,
       "end_year":2018,
       "end_month":11,
       "end_day":25,
    },
    function(data, status){
        console.log("Data: " + data + "\nStatus: " + status);
    });
    // socket.emit('createMessage',{
    //     from: 'User',
    //     text: jQuery('[name=message]').val()
    // })

})